#include "HAdminTradeSer.h"
#include <pthread.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <exception>  

const int MAX_CONNECTION = 8196;

#define ERR_EXIT(m) \
        do \
        { \
                perror(m); \
                exit(EXIT_FAILURE); \
        } while(0)

static void *
thread_start(void *arg)
{

    pthread_detach(pthread_self());
    Hwy_Epoller *tinfo = (Hwy_Epoller *)arg;

    struct sockaddr_in peeraddr;
    socklen_t peerlen;
    int connfd;

    int nready;
    while (1)
    {
        nready = tinfo->Wait(&*(tinfo->user_list.begin()), static_cast<int>(tinfo->user_list.size()), -1);
        if (nready == -1)
        {
            if (errno == EINTR)
                continue;
            ERR_EXIT("epoll_wait");
        }
        if (nready == 0)    // nothing happended
            continue;

        if ((size_t)nready == tinfo->user_list.size())
            tinfo->user_list.resize(tinfo->user_list.size()*2);

        for (int i = 0; i < nready; ++i)
        {
            task_struct *lis_st = (task_struct *)tinfo->user_list[i].data.ptr;
            if (lis_st->fd == tinfo->listenfd)
            {
                peerlen = sizeof(peeraddr);
                connfd = ::accept4(tinfo->listenfd, (struct sockaddr*)&peeraddr,
                        &peerlen, SOCK_NONBLOCK | SOCK_CLOEXEC);

                if (connfd == -1)
                {
                        ERR_EXIT("accept4");
                }


                std::cout<<"ip="<<inet_ntoa(peeraddr.sin_addr)<<
                    " port="<<ntohs(peeraddr.sin_port)<<std::endl;

                tinfo->clients.push_back(connfd);
            
                task_struct *cli_st = (task_struct *)new task_struct;
                cli_st->fd = connfd;
                tinfo->Add(connfd, cli_st, EPOLLIN);
            }
            else if (tinfo->user_list[i].events & EPOLLIN)
            {
                connfd = lis_st->fd;
                if (connfd < 0)
                    continue;

                char buf[8] = {0};
                int ret = read(connfd, buf, 8);
                // if (ret == -1)
                //     ERR_EXIT("read");
                try{
                    if (ret == 0)
                    {
                        std::cout<<"client close"<<std::endl;
                        close(connfd);
                        tinfo->Del(connfd, lis_st, 0);
                        tinfo->clients.erase(std::remove(tinfo->clients.begin(), tinfo->clients.end(), connfd), tinfo->clients.end());
                        continue;
                    }   
                }
                catch (std::exception){
                    continue;
                }
                
                // std::cout<<buf;
                // write(connfd, buf, strlen(buf));
            }

        }
    }
   return NULL ;
}



Hwy_Epoller::Hwy_Epoller( bool  bEt)
{
    listenfd    = -1;
    epollfd     = -1;
    _et           = bEt;
    _max_connections  = 8192;
    _start = false;
    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
}

Hwy_Epoller::~Hwy_Epoller()
{
    if ( listenfd  > 0)
    {
        close( listenfd );
    }
}

bool Hwy_Epoller::InitListenSocket()
{
    unsigned char buf[sizeof(struct in6_addr)];
    //int idlefd = open("/dev/null", O_RDONLY | O_CLOEXEC);
    //if ((listenfd = socket(AF_INET, SOCK_STREAM| SOCK_NONBLOCK| SOCK_CLOEXEC, IPPROTO_TCP)) < 0)
    if ((listenfd = socket(PF_INET, SOCK_STREAM , IPPROTO_TCP)) < 0)
        ERR_EXIT("socket");

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = PF_INET;
    servaddr.sin_port = htons(9238);
    servaddr.sin_addr.s_addr = inet_addr("192.168.1.9");//htonl(INADDR_ANY);//inet_pton(AF_INET, "127.0.0.1", buf);//htonl(INADDR_ANY);
    socklen_t addrlen = sizeof(servaddr);
    int on = 1;
    if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
         ERR_EXIT("setsockopt");
    
    if (bind(listenfd, (struct sockaddr*)&servaddr, addrlen) < 0)
        ERR_EXIT("bind");
    if (listen(listenfd, 25) < 0)
        ERR_EXIT("listen");
    
    Create(MAX_CONNECTION);

    // struct epoll_event event;
    // event.data.fd = listenfd;
    // event.events = EPOLLIN/* | EPOLLET*/;
    // epoll_ctl(epollfd, EPOLL_CTL_ADD, , &event);
    task_struct *lis_st = (task_struct *)new task_struct;
    lis_st->fd = listenfd;
    Add(listenfd, lis_st, EPOLLIN);
    _start = true;
    return _start;
}

void Hwy_Epoller::StartLis()
{
    pthread_t t_id;
    int ret = pthread_create(&t_id, NULL, thread_start, this);
    if (ret)
    {
        ERR_EXIT("pthread_create line:146");
    }
    //thread_start(this);
    std::cout << "HWYSER Init and Open is successed...\n";
}

void  Hwy_Epoller::Ctrl( int  fd,  void *data, unsigned int events,  int  op)
{
    struct  epoll_event  ev;
    ev.data.ptr= data;
    if ( _et )
    {
        ev.events   = events | EPOLLET ;
    }
    else
    {
        ev.events   = events;
    }

     epoll_ctl( epollfd  , op, fd, &ev);
}

void  Hwy_Epoller::Create( int  max_connections)
{
      _max_connections  = max_connections;
      epollfd  = epoll_create( _max_connections  + 1);
      user_list.resize(max_connections/2);
}

void  Hwy_Epoller::Add( int  fd,  void *data, unsigned int event)
{
     Ctrl(fd, data, event, EPOLL_CTL_ADD);
}

void  Hwy_Epoller::Mod( int  fd,  void *data, unsigned int event)
{
     Ctrl(fd, data, event, EPOLL_CTL_MOD);
}

void  Hwy_Epoller::Del( int  fd,  void *data, unsigned int event)
{
    delete (task_struct *)data;
     Ctrl(fd, data, event, EPOLL_CTL_DEL);
}

int  Hwy_Epoller::Wait(struct epoll_event *events, int maxevents, int timeout)
{
     return epoll_wait(epollfd, events, maxevents, timeout);
}

void Hwy_Epoller::Send_Fx_Change(Hwy_FX_PRICEORSIZE *data)
{
    try{
        for(auto it = clients.begin(); it != clients.end(); it++)
        {
            int len = write(*it, data, sizeof(Hwy_FX_PRICEORSIZE));
            if (len < 0 || len != sizeof(Hwy_FX_PRICEORSIZE))
            {
                perror("send data lost...");
                continue;
            }
        }
    }catch(std::exception){

    }
    
}
