#ifndef __HWYHADMINTRADE_H
#define __HWYHADMINTRADE_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/epoll.h>
#include "Hwy_package.h"

typedef std::vector<struct epoll_event> EventList;

struct task_struct
{
    int fd;
    std::map<std::string, bool> use_take_forex;
};

class  Hwy_Epoller
{
public :

     Hwy_Epoller( bool  bEt =  true );
     ~Hwy_Epoller();

    void  Create( int  max_connections);

    void  Add( int  fd,  void *data, unsigned int event);

    void  Mod( int  fd,  void *data, unsigned int event);

    void  Del( int  fd,  void *data, unsigned int event);

    void  Ctrl( int  fd,  void *data, unsigned int user_list,  int  op);

    int Wait(struct epoll_event *events, int maxevents, int timeout);

    void Send_Fx_Change(Hwy_FX_PRICEORSIZE *data);

    bool InitListenSocket();

    void StartLis();
    
    bool IsStart(){return _start;}

    std::vector<int> clients;
    EventList   user_list;
public:
    int     _max_connections ;
    int listenfd;
    int epollfd;
    bool  _et ;
    bool _start;
};

#endif //