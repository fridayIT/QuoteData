#include "HAdminTradeSer.h"
#include <iostream>
#include <unistd.h>
#include "../../inc/Hwy_package.h"

int main(void)
{
    Hwy_Epoller m_epoll(true);
    m_epoll.InitListenSocket();
    m_epoll.StartLis();
    std::cout << m_epoll.IsStart() << std::endl;
    while (1)
    {
        std::cout << "sleep 1 sec" << std::endl;
        sleep(1);
    }
    return 0;
}
