#include "HAdminTradeSer.h"
#include <pthread.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <exception>  
#include <unistd.h>
#include <fcntl.h>

const int MAX_CONNECTION = 8196;
const int RECV_OK = 8;
#define HWY_HOST "120.24.44.211"  //192.168.157.129 120.24.44.211

std::map<std::string, std::map<int, int>> take_fx_list;

#define ERR_EXIT(m) \
        do \
        { \
                perror(m); \
                exit(EXIT_FAILURE); \
        } while(0)

static void *
thread_start(void *arg)
{

    pthread_detach(pthread_self());
    Hwy_Epoller *tinfo = (Hwy_Epoller *)arg;

    struct sockaddr_in peeraddr;
    socklen_t peerlen;
    int connfd;

    int nready;
    while (1)
    {
        nready = tinfo->Wait(&*(tinfo->user_list.begin()), static_cast<int>(tinfo->user_list.size()), -1);
        if (nready == -1) {
            if (errno == EINTR)
                continue;
            ERR_EXIT("epoll_wait");
        }
        if (nready == 0)    // nothing happended
            continue;

        if ((size_t)nready == tinfo->user_list.size())
            tinfo->user_list.resize(tinfo->user_list.size()*2);

        for (int i = 0; i < nready; ++i)
        {
            TaskStruct *lis_st = (TaskStruct *)tinfo->user_list[i].data.ptr;
            if (lis_st->fd == tinfo->listenfd) {
                peerlen = sizeof(peeraddr);
                connfd = accept (tinfo->listenfd, (struct sockaddr*)&peeraddr, &peerlen);

                if (connfd == -1) {
                        ERR_EXIT("accept");
                }
                std::cout<<"ip="<<inet_ntoa(peeraddr.sin_addr)<<
                    " port="<<ntohs(peeraddr.sin_port)<<std::endl;


                // int on = 1;
                // if (setsockopt(connfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
                //     ERR_EXIT("setsockopt");
                std::cout << "connfd : " << connfd << std::endl;
                int set_flag = fcntl(connfd, F_GETFL);
                if (fcntl(connfd, F_SETFL, set_flag | O_NONBLOCK | SOCK_CLOEXEC) < 0)
                    perror("fcntl Function set connfd noblock is err:");

                //Send all Fxname
                tinfo->SendAllFx(connfd);

                // login
                //  auth
                tinfo->clients.push_back(connfd);
            
                TaskStruct *cli_st = (TaskStruct *)new TaskStruct(connfd, tinfo->m_fx_list);
                tinfo->Add(connfd, cli_st, EPOLLIN);
            }
            else if (tinfo->user_list[i].events & EPOLLIN)
            {
                if (lis_st->fd < 0)
                    continue;
                tinfo->task_queue.push(lis_st);
            }
        }
    }
   return NULL ;
}

static void *
thr_begin_consume(void *arg)
{
    pthread_detach(pthread_self());
    Hwy_Epoller *tinfo = (Hwy_Epoller *)arg;
    TaskStruct *task = NULL;

    while (1)
    {
        if (tinfo->task_queue.empty()) {
            sleep(1);
            std::cout << "client nums:" << tinfo->clients.size() << std::endl;
        }
        else {
            try {
                task = tinfo->task_queue.front();
                tinfo->task_queue.pop();   ///////////
                Hwy_package_len cmd_buf;
                int ret = 0;

                while (1)
                {
                    int cmd;
                    int len;
                    ret = read(task->fd, (char *)&cmd_buf, RECV_OK);
                    if (ret == RECV_OK) {
                        task->Doit(cmd_buf);
                    }  
                    else {
                        break;
                    }
                    //std::cout << "recv ruturn ret:"<<ret << std::endl;
                }
                
                if (ret == 0) {
                    //std::cout<<"client close"<<std::endl;
                    close(task->fd);
                    tinfo->Del(task->fd, task, 0);
                    tinfo->clients.erase(std::remove(tinfo->clients.begin(), tinfo->clients.end(), task->fd), tinfo->clients.end());
                    continue;
                }
                else if (ret < 0)
                {
                    if (errno == EAGAIN)
                    {
                        continue;
                    }
                    //std::cout << "error :" << errno << std::endl;
                    //perror("ERR :");
                }

            }
            catch (std::exception) {
                tinfo->Del(task->fd, task, 0);
                //perror("Function thr_begin_consume connfd read()");
                continue;
            }          

        }
    }
}


Hwy_Epoller::Hwy_Epoller( bool  bEt)
{
    listenfd    = -1;
    epollfd     = -1;
    _et           = bEt;
    _max_connections  = 8192;
    _start = false;
    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
}

Hwy_Epoller::~Hwy_Epoller()
{
    if ( listenfd  > 0)
    {
        close( listenfd );
    }
}

bool Hwy_Epoller::InitListenSocket(std::map<int, std::string>  *pm_fx_list)
{
    if (IsStart())
        return true;

    m_fx_list = pm_fx_list;
    unsigned char buf[sizeof(struct in6_addr)];
    //int idlefd = open("/dev/null", O_RDONLY | O_CLOEXEC);
    //if ((listenfd = socket(AF_INET, SOCK_STREAM| SOCK_NONBLOCK| SOCK_CLOEXEC, IPPROTO_TCP)) < 0)
    if ((listenfd = socket(PF_INET, SOCK_STREAM , IPPROTO_TCP)) < 0)
        ERR_EXIT("socket");

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = PF_INET;
    servaddr.sin_port = htons(9238);
    servaddr.sin_addr.s_addr = inet_addr(HWY_HOST);//inet_addr("127.0.0.1");//192.168.157.129 192.168.1.9htonl(INADDR_ANY);//inet_pton(AF_INET, "127.0.0.1", buf);//htonl(INADDR_ANY);
    socklen_t addrlen = sizeof(servaddr);
    int on = 1;
    if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
         ERR_EXIT("setsockopt");

    linger so_linger;
    so_linger.l_onoff = 1;
    so_linger.l_linger = 30;
    setsockopt(listenfd,
        SOL_SOCKET,
        SO_LINGER,
        (char *)&so_linger,
        sizeof so_linger);
    
    if (bind(listenfd, (struct sockaddr*)&servaddr, addrlen) < 0)
        ERR_EXIT("bind");
    if (listen(listenfd, 100) < 0)
        ERR_EXIT("listen");
    
    Create(MAX_CONNECTION);

    // struct epoll_event event;
    // event.data.fd = listenfd;
    // event.events = EPOLLIN/* | EPOLLET*/;
    // epoll_ctl(epollfd, EPOLL_CTL_ADD, , &event);
    TaskStruct *lis_st = (TaskStruct *)new TaskStruct;
    lis_st->fd = listenfd;
    Add(listenfd, lis_st, EPOLLIN);
    _start = true;
    return _start;
}

void Hwy_Epoller::StartLis()
{
    pthread_t t_id;
    int ret = pthread_create(&t_id, NULL, thread_start, this);
    if (ret)
        ERR_EXIT("pthread_create line: 162");

    //thread_start(this);
    std::cout << "HWYSER Init and Open is successed...\n";
}

void Hwy_Epoller::ConsumeQueue()
{
    pthread_t t_id;
    int ret = pthread_create(&t_id, NULL, thr_begin_consume, this);
    if (ret)
        ERR_EXIT("pthread_create line: 173");
}

void  Hwy_Epoller::Ctrl( int  fd,  void *data, unsigned int events,  int  op)
{
    struct  epoll_event  ev;
    ev.data.ptr= data;
    if ( _et ) {
        ev.events   = events | EPOLLET ;
    }
    else {
        ev.events   = events;
    }

     epoll_ctl( epollfd  , op, fd, &ev);
}

void  Hwy_Epoller::Create( int  max_connections)
{
      _max_connections  = max_connections;
      epollfd  = epoll_create( _max_connections  + 1);
      user_list.resize(max_connections/2);
}

void  Hwy_Epoller::Add( int  fd,  void *data, unsigned int event)
{
     Ctrl(fd, data, event, EPOLL_CTL_ADD);
}

void  Hwy_Epoller::Mod( int  fd,  void *data, unsigned int event)
{
     Ctrl(fd, data, event, EPOLL_CTL_MOD);
}

void  Hwy_Epoller::Del( int  fd,  void *data, unsigned int event)
{
    delete (TaskStruct *)data;
    Ctrl(fd, data, event, EPOLL_CTL_DEL);
}

int  Hwy_Epoller::Wait(struct epoll_event *events, int maxevents, int timeout)
{
     return epoll_wait(epollfd, events, maxevents, timeout);
}

void Hwy_Epoller::Send_Fx_Change(void *data, int type)
{
    // std::cout << data->Fx_name << std::endl;
    // std::cout << data->updatetime << std::endl;

    Hwy_FX_PRICE *fx_code = (Hwy_FX_PRICE *)data;
    std::string fx_name = fx_code->Fx_name;

        int send_len = 0;
        switch(type)
        {
        case 1:
            send_len = sizeof(Hwy_FX_PRICE);
            break;
        case 2:
            send_len = sizeof(Hwy_FX_SIZE);
            break;
        default:
            return;
        }
        auto it = clients.begin();
        for( ;it != clients.end();)
        {
            std::cout << fx_name << "   " << take_fx_list[fx_name][*it] << std::endl;
            if (take_fx_list[fx_name][*it] != 1) {
                it++;
                continue;
            }
            try{
                int len = write(*it, (char *)fx_code, send_len);
                if (len < 0 || len != send_len)
                {
                    std::cout << ("send data lost... line:307\n");

                    //Del(*it, task, 0);
                    //close(connfd);

                    it = clients.erase(it);
                    break;
                }
                it++;
            } catch(std::exception) {
                close(*it);
                it = clients.erase(it);
            }
        }
    
}

void Hwy_Epoller::SendAllFx(int con)
{
    Hwy_package_len cmd_len;
    cmd_len.cmd = HCODE_FX_LIST;
    cmd_len.len = m_fx_list->size();
    const int fx_name_len = 12;

    int ret = write(con, (char *)&cmd_len, sizeof(Hwy_package_len));
    if (ret < 1)
    {
        perror("write");
        return;
    }

    char send_fx[cmd_len.len][fx_name_len];

    int i = 0;
    for (auto it = m_fx_list->begin(); it != m_fx_list->end(); it++) {
        strncpy(send_fx[i++], it->second.c_str(), fx_name_len);
    }
    ret = write(con, (char *)send_fx, cmd_len.len * fx_name_len);
    if (ret < 1)
    {
        perror("write");
    }

}



 void TaskStruct::TakeForex(const char *recv_buf)
 {
    Hwy_Req_FX *take_fx = (Hwy_Req_FX *)recv_buf;
    std::string take_code = take_fx->fx_code;
    //std::cout << "fx_name:  " << take_fx->fx_code << "   need: " <<  << std::endl;
    for (auto it = m_fx_list->begin(); it != m_fx_list->end(); it++) {
        if (take_code == it->second)//!strncmp(take_fx->fx_code, it->second.c_str(), strlen(take_fx->fx_code))
        {
            std::cout << "Auth FX OK...\n";
            if (take_fx->need) {
                take_fx_list[take_code][fd] = 1;
            }
            else {
                take_fx_list[take_code][fd] = 0;
            }
            break;
        }
    }
 }

void TaskStruct::Doit(Hwy_package_len cmd_buf)
{
    int ret = 0;
    if (cmd_buf.len == 0)
    {
        perror("recv buf is 0. nothing to do.");
        return;
    }
    std::cout << cmd_buf.len << "     " << "sssssss" << std::endl;
    char *recv_buf = (char *)calloc(cmd_buf.len, sizeof(char));
    if (recv_buf == NULL)
    {
        perror("TaskStruct::Doit malloc()");
        return;
    }

    ret = read(fd, recv_buf, cmd_buf.len);
    if (ret < 0) {
        std::cout << ("TaskStruct::Doit read()\n");
        return;
    }

    switch(cmd_buf.cmd) {
    case CLIHCODE_IB_TAKE_FOREX:
        TakeForex(recv_buf);
        break;
    }
    free(recv_buf);
}          