#ifndef HPOSIXCLIENTSOCKET_DEF
#define HPOSIXCLIENTSOCKET_DEF

#include "HClientSocketBase.h"
#include <arpa/inet.h>
#include <errno.h>
#include <sys/select.h>
#include <sys/fcntl.h>
#include <unistd.h>

// helpers
inline bool SocketsInit() { return true; };
inline bool SocketsDestroy() { return true; };
inline int SocketClose(int sockfd) { return close( sockfd); };

inline bool SetSocketNonBlocking(int sockfd) { 
    // get socket flags
    int flags = fcntl(sockfd, F_GETFL);
    if (flags == -1)
	return false;

    // set non-blocking mode
    return ( fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == 0);
};

class EWrapper;

class HPosixClientSocket : public HClientSocketBase
{
public:

    explicit HPosixClientSocket( EWrapper *ptr);
    ~HPosixClientSocket();

    // override virtual funcs from EClient
    bool eConnect( const char *host, unsigned int port, int clientId = 0, bool extraAuth = false);
    void eDisconnect();

    bool isSocketOK() const;
    int fd() const;

private:

    int send( const char* buf, size_t sz);
    int receive( char* buf, size_t sz);

public:
    // callback from socket
    void onReceive();
    void onSend();
    void onError();

private:

    void onConnect();
    void onClose();

public:
    // helper
    bool handleSocketError();

private:

    int m_fd;
};

#endif
