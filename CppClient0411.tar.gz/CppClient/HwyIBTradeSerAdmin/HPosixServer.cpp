#include "HPosixServer.h"

#include "HPosixClientSocket.h"
//#include "HPosixClientSocketPlatform.h"
#include "HClientSocketBase.h"
#include <iostream>
#include <vector>
#include <string>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include "HAdminTradeSer.h"
#include "Hwy_package.h"

#define ALLFX "USD AUD CAD CHF CNH CZK DKK  EUR  GBP HKD  HUF  ILS JPY  MXN NOK NZD  PLN RUB SEK  SGD ZAR KRW"
//#define ALLFX "USD DDK"
#include "Contract.h"
#include "Order.h"

#include <stdio.h>

const int PING_DEADLINE = 20; // seconds
const int SLEEP_BETWEEN_PINGS = 30; // seconds
long HWY_DIF_BETWENEN_IB = 0;

Hwy_Epoller m_epoll;

void PrintAllFX(std::map<int, std::string> &fx)
{
    int i = 1;
    for(auto it = fx.begin(); it != fx.end(); it++)
    {
        std::cout << it->second << "  ";
        if (i++ % 5 == 0)
            std::cout << "\n";
    }
}

 void * get_Data(void *arg)
 {
    PosixHwyServer *Ser = (PosixHwyServer *)arg;
    int i = 0;
    while (1)
    {
        Ser->m_pClient->checkMessages();
        usleep(1000000);
        if (i % 3600 == 0)
        {
            Ser->m_pClient->reqCurrentTime();
            i = 0;
        }
        i++;
        //m_pClient->reqCurrentTime();
        //std::cout << "sleep 0.5 sec.\n" ;
    }
 }


///////////////////////////////////////////////////////////
// member funcs
/*
PosixHwyServer::PosixHwyServer()
    : m_pClient(new HPosixClientSocket(this))
    , m_state(ST_CONNECT)
    , m_sleepDeadline(0)
    , m_orderId(0)
{
}*/
PosixHwyServer::PosixHwyServer():m_pClient(new HPosixClientSocket(this)),m_state(ST_CONNECT),
    m_sleepDeadline(0), m_orderId(0)
{
}

PosixHwyServer::~PosixHwyServer()
{
}

bool PosixHwyServer::connect(const char *host, unsigned int port, int clientId)
{
    // trying to connect
    printf( "Connecting to %s:%d clientId:%d\n", !( host && *host) ? "127.0.0.1" : host, port, clientId);

    bool bRes = m_pClient->eConnect( host, port, clientId, /* extraAuth */ false);

    if (bRes) {
        printf( "Connected to %s:%d clientId:%d\n", !( host && *host) ? "127.0.0.1" : host, port, clientId);
        
        if (!m_epoll.IsStart())
        {
            m_epoll.InitListenSocket(&m_id_fx);
            m_epoll.StartLis();
            m_epoll.ConsumeQueue();
        }
        if (!m_epoll.IsStart())
            exit(-1);
    }
    else
        printf( "Cannot connect to %s:%d clientId:%d\n", !( host && *host) ? "127.0.0.1" : host, port, clientId);

    return bRes;
}

void PosixHwyServer::disconnect() const
{
    m_pClient->eDisconnect();

    printf ( "\nDisconnected\n");
}

bool PosixHwyServer::isConnected() const
{
    return m_pClient->isSocketOK();
}

void PosixHwyServer::reSetState(State flag)
{
    m_state = flag;
}

void PosixHwyServer::processMessages()
{
    fd_set readSet, writeSet, errorSet;

    struct timeval tval;
    tval.tv_usec = 0;
    tval.tv_sec = 1;
    
    static bool no_create_ptr = true;
    if (no_create_ptr)
    {

        pthread_t tid;
        pthread_create(&tid, NULL, get_Data,(void *)this);
        no_create_ptr = false;
    }

    time_t now = time(NULL);
    //std::cout << m_state << std::endl;
    switch (m_state) {
	case ST_PLACEORDER:

                 //m_pClient->setLogLevel(3);
                 HGetForex();
	    break;
	case ST_PLACEORDER_ACK:
	    break;
	case ST_CANCELORDER:
	    cancelOrder();
	    break;
	case ST_CANCELORDER_ACK:
	    break;
	case ST_PING:
	    reqCurrentTime();
	    break;
	case ST_PING_ACK:
	    if( m_sleepDeadline < now) {
                    disconnect();
                    return;
	    }
	    break;
	case ST_IDLE:
	    if( m_sleepDeadline < now) {
                    m_state = ST_PING;
                    return;
	    }
	    break;
            case ST_GETQOUTE:
                //m_pClient->onReceive();
                //std::cout <<"Good"<< std::endl;
                //reqCurrentTime();
                //m_pClient->checkMessages();
                sleep(200);
                PrintAllFX(m_id_fx);
                break;
    }

    if( m_sleepDeadline > 0) {
	// initialize timeout with m_sleepDeadline - now
		tval.tv_sec = m_sleepDeadline - now;
    }

    if( m_pClient->fd() >= 0 ) {

	FD_ZERO( &readSet);
	errorSet = writeSet = readSet;

	FD_SET( m_pClient->fd(), &readSet);

	if( !m_pClient->isOutBufferEmpty())
	    FD_SET( m_pClient->fd(), &writeSet);

	FD_SET( m_pClient->fd(), &errorSet);

	int ret = select( m_pClient->fd() + 1, &readSet, &writeSet, &errorSet, &tval);

	if( ret == 0) { // timeout
	    return;
	}

	if( ret < 0) {	// error
	    disconnect();
	    return;
	}

	if( m_pClient->fd() < 0)
	    return;

	if( FD_ISSET( m_pClient->fd(), &errorSet)) {
	    // error on socket
	    m_pClient->onError();
	}

	if( m_pClient->fd() < 0)
	    return;

	if( FD_ISSET( m_pClient->fd(), &writeSet)) {
	    // socket is ready for writing
	    m_pClient->onSend();
	}

	if( m_pClient->fd() < 0)
	    return;

	if( FD_ISSET( m_pClient->fd(), &readSet)) {
	    // socket is ready for reading
	    m_pClient->onReceive();
	}
    }
}

//////////////////////////////////////////////////////////////////
// methods
void PosixHwyServer::reqCurrentTime()
{
    printf( "Requesting Current Time\n");

    // set ping deadline to "now + n seconds"
    m_sleepDeadline = time( NULL) + PING_DEADLINE;

    m_state = ST_PING_ACK;

    m_pClient->reqCurrentTime();
}

void PosixHwyServer::HGetForex()
{
    HForex_ h_forex[250*2];

    const char *all_fx = ALLFX;
    std::vector<std::string>  v_fx;

    std::string once_fx;
    while (*all_fx)
    {   
        if (*all_fx != ' ') {
            once_fx += *all_fx;    
        }   
        else if (*(all_fx+1) != ' '){ 
            v_fx.push_back(once_fx);
            once_fx.clear();
        }   
        all_fx++;
    }  

    int fx_count = v_fx.size();
    int i_count = 0;

    for (int i = 0; i < fx_count; i++)
    {   
        for (int j = 0; j < fx_count; ++j)
        {   
            h_forex[i_count++].SetForex(v_fx[i].c_str(), "CASH", "IDEALPRO", v_fx[j].c_str());
        }   
    } 

    Order order;
    TagValueListSPtr sptr;
    static int save_mkt_id = m_orderId;

    m_state = ST_GETQOUTE;

    int count = 0;
    int orderId = save_mkt_id;

    while (count < i_count)
    {
        Contract contract;
        contract.secType = h_forex[count].secType;
        // contract.symbol  = "GBP";
        contract.symbol = h_forex[count].symbol;
        contract.exchange = h_forex[count].exchange;
        contract.currency = h_forex[count].currency;
        // contract.currency = "CNH";

        m_id_fx[orderId] = h_forex[count].symbol + "." + h_forex[count].currency;
        m_pClient->reqMktData(orderId++, contract, "", false, sptr);
        usleep(100000);
        count++;
    }
    

   // m_pClient->placeOrder( m_orderId, contract, order);

}

void PosixHwyServer::cancelOrder()
{

    printf( "Cancelling Order %ld\n", m_orderId);

    m_state = ST_CANCELORDER_ACK;

    m_pClient->cancelOrder( m_orderId);

}

///////////////////////////////////////////////////////////////////
// events
void PosixHwyServer::orderStatus( OrderId orderId, const std::string &status, double filled,
       double remaining, double avgFillPrice, int permId, int parentId,
       double lastFillPrice, int clientId, const std::string& whyHeld)

{
    if( orderId == m_orderId) {
	if( m_state == ST_PLACEORDER_ACK && (status == "PreSubmitted" || status == "Submitted"))
	    m_state = ST_CANCELORDER;

	if( m_state == ST_CANCELORDER_ACK && status == "Cancelled")
	    m_state = ST_PING;

	printf( "Order: id=%ld, status=%s\n", orderId, status.c_str());
    }
}

void PosixHwyServer::nextValidId( OrderId orderId)
{
    m_orderId = orderId;

    m_state = ST_PLACEORDER;
}

void PosixHwyServer::currentTime( long time)
{
    //std::cout << "ser time: " << time << std::endl;
    time_t t = ( time_t)time;
    time_t now = ::time(NULL);
    //std::cout << "t - now:" << t - now << std::endl;
    //struct tm * timeinfo = localtime ( &t);
    HWY_DIF_BETWENEN_IB =  t - now ;
    sleep(1);
 //    if ( m_state == ST_PING_ACK) {
	// time_t t = ( time_t)time;
	// struct tm * timeinfo = localtime ( &t);
	// printf( "The current date/time is: %s", asctime( timeinfo));

	// time_t now = ::time(NULL);
	// m_sleepDeadline = now + SLEEP_BETWEEN_PINGS;

	// m_state = ST_IDLE;
 //    }
}

void PosixHwyServer::error(const int id, const int errorCode, const std::string errorString)
{
  printf( "Error id=%d, errorCode=%d, msg=%s\n",  id, errorCode, errorString.c_str());

  switch(errorCode)
  {
    case 200:
        //std::cout << m_id_fx[id] << std::endl;
        m_id_fx.erase(id);
        break;
    case 2104:
        break;
    case 2106:
        break;
    case 509:
        break;
    case 504:
        break;
    default:
        kill(getpid(), SIGINT);
        return;
        break;
  }

    //if( id == -1 && errorCode == 1100) // if "Connectivity between IB and TWS has been lost"
    if( id == -1 && errorCode != 2104 && errorCode != 2106)
        disconnect();
}

void PosixHwyServer::tickPrice( TickerId tickerId, TickType field, double price, int canAutoExecute) 
{
    time_t now = ::time(NULL);

    m_id_fx_price[tickerId].pack_len.cmd = HCODE_FX_PRICE;
    m_id_fx_price[tickerId].pack_len.len = sizeof(Hwy_FX_PRICE) - sizeof(Hwy_package_len);


    m_id_fx_price[tickerId].field_type = field;
    strcpy(m_id_fx_price[tickerId].Fx_name, m_id_fx[tickerId].c_str());
    m_id_fx_price[tickerId].updatetime = (unsigned long)now + HWY_DIF_BETWENEN_IB;

    switch (field)
    {
        case 1:
            m_id_fx_price[tickerId].bid_price = price;
            break;
        case 2:
            m_id_fx_price[tickerId].ask_price = price;
            break;
        case 4:
            m_id_fx_price[tickerId].field_1 = price;
            break;
        case 6:
            m_id_fx_price[tickerId].field_2 = price;
            break;
        case 7:
            m_id_fx_price[tickerId].field_3 = price;
            break;
        case 9:
            m_id_fx_price[tickerId].field_4 = price;
            break;
    }
    
    m_epoll.Send_Fx_Change(&m_id_fx_price[tickerId], 1);
}
void PosixHwyServer::tickSize( TickerId tickerId, TickType field, int size) 
{
    time_t now = ::time(NULL);
    Hwy_FX_SIZE data;

    m_id_fx_size[tickerId].pack_len.cmd = HCODE_FX_SIZE;
    m_id_fx_size[tickerId].pack_len.len = sizeof(Hwy_FX_SIZE) - sizeof(Hwy_package_len);

    m_id_fx_size[tickerId].updatetime = (unsigned long)now + HWY_DIF_BETWENEN_IB;
    // switch (field)
    // {
    //     case 0:
    //         m_id_fx_size[tickerId].field_size = size;
    //         std::cout << "\033[31m买价尺寸--";
    //          break;
    //     case 3:
    //         m_id_fx_size[tickerId].field_size = size;
    //         std::cout << "\033[32m卖价尺寸--";
    //         break;
    //     case 5:
    //         std::cout << " 最后价尺寸--";
    //         break;
    //     case 8:
    //         std::cout << "交易量--";
    //         break;
    // }
    // std::cout << " FX: " << m_id_fx[tickerId] << " size: " << size  << std::endl << "\033[0m";
    data = m_id_fx_size[tickerId];
    //m_epoll.Send_Fx_Change(&data, 2);
}
void PosixHwyServer::tickOptionComputation( TickerId tickerId, TickType tickType, double impliedVol, double delta,
    double optPrice, double pvDividend,
    double gamma, double vega, double theta, double undPrice) 
{
    std::cout << "tickerId :" << tickerId << " tickType: " << tickType << " impliedVol:"<< impliedVol << " delta:"<< delta   << " optPrice:" << optPrice << std::endl;
       
}
void PosixHwyServer::tickGeneric(TickerId tickerId, TickType tickType, double value) 
{ 
    std::cout <<"tickGeneric vaule"<< value << std::endl;
    std::cout << "name-" << m_id_fx[tickerId] << std::endl;
    std::cout << "tickType:" << tickType << std::endl;
    // TickType.getField(tickType);
}
void PosixHwyServer::tickString(TickerId tickerId, TickType tickType, const std::string& value) {
 std::cout <<"tickString" << std::endl;
}
void PosixHwyServer::tickEFP(TickerId tickerId, TickType tickType, double basisPoints, const std::string& formattedBasisPoints,
			       double totalDividends, int holdDays, const std::string& futureExpiry, double dividendImpact, double dividendsToExpiry) 
{
    std::cout <<"tickEFP"<<std::endl;
}
void PosixHwyServer::openOrder( OrderId orderId, const Contract&, const Order&, const OrderState& ostate) {}
void PosixHwyServer::openOrderEnd() {}
void PosixHwyServer::winError( const std::string &str, int lastError)
 { 
    printf( "ReqMaket Error id=%d, msg=%s\n",lastError, str.c_str());


}
void PosixHwyServer::connectionClosed() {}
void PosixHwyServer::updateAccountValue(const std::string& key, const std::string& val,
					  const std::string& currency, const std::string& accountName) {}
void PosixHwyServer::updatePortfolio(const Contract& contract, double position,
	double marketPrice, double marketValue, double averageCost,
	double unrealizedPNL, double realizedPNL, const std::string& accountName){}
void PosixHwyServer::updateAccountTime(const std::string& timeStamp) {}
void PosixHwyServer::accountDownloadEnd(const std::string& accountName) {}
void PosixHwyServer::contractDetails( int reqId, const ContractDetails& contractDetails) {}
void PosixHwyServer::bondContractDetails( int reqId, const ContractDetails& contractDetails) {}
void PosixHwyServer::contractDetailsEnd( int reqId) {}
void PosixHwyServer::execDetails( int reqId, const Contract& contract, const Execution& execution) {}
void PosixHwyServer::execDetailsEnd( int reqId) {}

void PosixHwyServer::updateMktDepth(TickerId id, int position, int operation, int side,
				      double price, int size) {}
void PosixHwyServer::updateMktDepthL2(TickerId id, int position, std::string marketMaker, int operation,
					int side, double price, int size) {}
void PosixHwyServer::updateNewsBulletin(int msgId, int msgType, const std::string& newsMessage, const std::string& originExch) {}
void PosixHwyServer::managedAccounts( const std::string& accountsList) {}
void PosixHwyServer::receiveFA(faDataType pFaDataType, const std::string& cxml) {}
void PosixHwyServer::historicalData(TickerId reqId, const std::string& date, double open, double high,
				      double low, double close, int volume, int barCount, double WAP, int hasGaps) {}
void PosixHwyServer::scannerParameters(const std::string &xml) {}
void PosixHwyServer::scannerData(int reqId, int rank, const ContractDetails &contractDetails,
       const std::string &distance, const std::string &benchmark, const std::string &projection,
       const std::string &legsStr) {}
void PosixHwyServer::scannerDataEnd(int reqId) {}
void PosixHwyServer::realtimeBar(TickerId reqId, long time, double open, double high, double low, double close,
				   long volume, double wap, int count) {}
void PosixHwyServer::fundamentalData(TickerId reqId, const std::string& data) {}
void PosixHwyServer::deltaNeutralValidation(int reqId, const UnderComp& underComp) {}
void PosixHwyServer::tickSnapshotEnd(int reqId) {}
void PosixHwyServer::marketDataType(TickerId reqId, int marketDataType) {}
void PosixHwyServer::commissionReport( const CommissionReport& commissionReport) {}
void PosixHwyServer::position( const std::string& account, const Contract& contract, double position, double avgCost) {}
void PosixHwyServer::positionEnd() {}
void PosixHwyServer::accountSummary( int reqId, const std::string& account, const std::string& tag, const std::string& value, const std::string& curency) {}
void PosixHwyServer::accountSummaryEnd( int reqId) {}
void PosixHwyServer::verifyMessageAPI( const std::string& apiData) {}
void PosixHwyServer::verifyCompleted( bool isSuccessful, const std::string& errorText) 
{
    std::cout << "verifyCompleted func  " << errorText << std::endl;
}
void PosixHwyServer::displayGroupList( int reqId, const std::string& groups) {}
void PosixHwyServer::displayGroupUpdated( int reqId, const std::string& contractInfo) {}

void PosixHwyServer::verifyAndAuthMessageAPI( const std::string& apiData, const std::string& xyzChallange) {};
void PosixHwyServer::verifyAndAuthCompleted( bool isSuccessful, const std::string& errorText) 
{
    std::cout << "verifyAndAuthCompleted func  " << errorText << std::endl;
}


void PosixHwyServer::connectAck() {}
void PosixHwyServer::positionMulti( int reqId, const std::string& account, 
    const std::string& modelCode, const Contract& contract,
    double pos, double avgCost) {}
void PosixHwyServer::positionMultiEnd( int reqId) {}
void PosixHwyServer::accountUpdateMulti( int reqId, const std::string& account, const std::string& modelCode, const std::string& key, const std::string& value, const std::string& currency) {}
void PosixHwyServer::accountUpdateMultiEnd( int reqId) {}



/************************************************************************/
void PosixHwyServer::reqMktData(TickerId tickerId, const Contract& contract,
			       const std::string& genericTicks, bool snapshot, const TagValueListSPtr& mktDataOptions)
{
	m_pClient->reqMktData(tickerId,  contract,  genericTicks,  snapshot,  mktDataOptions);
}