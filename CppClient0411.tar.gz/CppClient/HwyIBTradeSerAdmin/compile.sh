#! /bin/sh
rm HwyIBServer -f
g++ -g main.cpp HAdminTradeSer.cpp HPosixServer.cpp HClientSocketBase.cpp HPosixClientSocket.cpp -I../inc -L. -lhwyIBA -o HwyIBServer -std=c++11 -lpthread 2>log.txt
