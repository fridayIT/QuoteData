#include <iostream>
#include <stdio.h>
# include <unistd.h>
#include <stdlib.h>
#include "HPosixServer.h"
#include <signal.h>

const unsigned MAX_ATTEMPTS = 50;
const unsigned SLEEP_TIME = 1;

enum BOOL{FALSE, TRUE};

PosixHwyServer client;

void sigint_handler(int signal)
{
    if (client.isConnected())
    {
        client.disconnect();
    }
    return;
}

void exit_handler(int signal)
{
    if (client.isConnected())
    {
        client.disconnect();
    }
    exit(0);
}

int main(int argc, char **argv)
{
    const char *host = argc > 1 ? argv[1] : "120.25.93.6"; //192.168.1.6 127.0.0.1
    unsigned int port = 7496;
    int clientId = 8;
    int TickerID = 64;
/*
	Contract contract;

	contract.symbol = "IBM";
	contract.secType = "STK";
	contract.exchange = "SMART";
	contract.currency = "USD";
            client.m_pClient->reqMktData(TickerID, contract, "162", FALSE);
*/
    unsigned attempt = 0;
    printf( "Start of POSIX Socket Client Test %u\n", attempt);

    signal(SIGINT, sigint_handler);

    for (;;) {
        ++attempt;
        printf( "Attempt %u of %u\n", attempt, MAX_ATTEMPTS);
        client.connect( host, port, clientId);

        while( client.isConnected()) {
        	client.processMessages();
        }
        if ( !client.isConnected()){
            client.reSetState(State::ST_PLACEORDER);
        }

        // if( attempt >= MAX_ATTEMPTS) {
        // 	break;
        // }

        printf( "Sleeping %u seconds before next attempt\n", SLEEP_TIME);
        sleep( SLEEP_TIME);
    }

    printf ( "End of POSIX Socket Client Test\n");
    return 0;
}

