#!/usr/bin/env python
#coding=utf8
import pika
import time
from datetime import datetime

credentials = pika.PlainCredentials('guest', 'guest')
parameters = pika.ConnectionParameters('120.25.93.6',5672,'/',credentials)  
connection = pika.BlockingConnection(parameters)    
channel =connection.channel()
 
#channel.exchange_declare(exchange='exchange2', type='direct')

routing = 'yunsoft_qoute.qoute_day'
result =channel.queue_declare(exclusive=True)
queue_name =result.method.queue

channel.queue_bind(exchange='exchange',
                   queue=queue_name,
                   routing_key=routing)

print' [*] Waiting for exchange. To exit press CTRL+C'
 
def callback(ch, method, properties, body):
    print" [x] Received %r"%(body,)
    data_list = body.split('|')
    sql_qoute = {}
    print repr(data_list[0])
    sql_qoute['updatetime'] = new_time = datetime.strptime(data_list[0],'%Y-%m-%d %H:%M:%S')
    sql_qoute['market'] = data_list[1]
    sql_qoute['code'] = data_list[2]
    sql_qoute['open'] = float(data_list[3])
    sql_qoute['high'] = float(data_list[4])
    sql_qoute['low'] = float(data_list[5])
    sql_qoute['close'] = float(data_list[6])
    sql_qoute['amount'] = float(data_list[7])
    sql_qoute['volume'] = float(data_list[8])
    print sql_qoute
    ch.basic_ack(delivery_tag = method.delivery_tag)
 
channel.basic_qos(prefetch_count=1)
channel.basic_consume(callback,
                      queue=queue_name)
 
channel.start_consuming()
