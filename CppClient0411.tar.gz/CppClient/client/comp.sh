#! /bin/sh

rm -f err_war.txt
ls *.cpp | xargs g++ -fPIC -g -c -lpthread -std=c++11 -I../inc
