#ifndef __HWYHADMINTRADE_H
#define __HWYHADMINTRADE_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <queue>
#include <string>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/epoll.h>
#include "Hwy_package.h"

typedef std::vector<struct epoll_event> EventList;

class TaskStruct
{
public:
    TaskStruct(int connfd=-1, std::map<int, std::string>  *p_fx_list = NULL, bool state=false):fd(connfd), t_state(state){m_fx_list=p_fx_list;}
    int fd;
    bool t_state;
    std::map<std::string, bool> use_take_forex;
    void TakeForex(const char *recv_buf);
    void Doit(Hwy_package_len cmd_buf);
    std::map<int, std::string>  *m_fx_list;
};



class  Hwy_Epoller
{
public :

     Hwy_Epoller( bool  bEt =  true );
     ~Hwy_Epoller();

    void  Create( int  max_connections);

    void  Add( int  fd,  void *data, unsigned int event);

    void  Mod( int  fd,  void *data, unsigned int event);

    void  Del( int  fd,  void *data, unsigned int event);

    void  Ctrl( int  fd,  void *data, unsigned int user_list,  int  op);

    int Wait(struct epoll_event *events, int maxevents, int timeout);

    void Send_Fx_Change(void *data, int type);

    bool InitListenSocket(std::map<int, std::string>  *);

    void StartLis();

    void ConsumeQueue();
    
    bool IsStart(){return _start;}

    void SendAllFx(int);

    std::vector<int> clients;
    std::queue<TaskStruct *> task_queue;
    std::map<int, std::string>  *m_fx_list;
    EventList   user_list;
public:
    int     _max_connections ;
    int listenfd;
    int epollfd;
    bool  _et ;
    bool _start;
};

#endif //