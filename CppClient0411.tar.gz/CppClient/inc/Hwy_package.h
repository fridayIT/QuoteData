#pragma once

#pragma pack(4)

enum {
    HCODE_FX_PRICE = 1006,
    HCODE_FX_SIZE,
    HCODE_FX_LIST
};

enum {
    CLIHCODE_IB_TAKE_FOREX = 2001,
};

struct Hwy_package_len
{
    Hwy_package_len() :cmd(0), len(0) {}
    int cmd;
    int len;
};

struct Hwy_FX_PRICE
{
    Hwy_FX_PRICE() : bid_price(0), ask_price(0), field_type(0), updatetime(0) {
        field_1 = 0;
        field_2 = 0;
        field_3 = 0;
        field_4 = 0;
    }
    
    Hwy_package_len     pack_len;
    char                        Fx_name[20];            //名称，例如USD.CHF
    unsigned long long  updatetime;             //更新时间
    int                         field_type;

    float                       bid_price;             //买价
    float                       ask_price;            //卖价
    float                       field_1;                //最后价       
    float                       field_2;                //最高价       
    float                       field_3;                //最低价
    float                       field_4;                //收盘价
};

struct Hwy_FX_SIZE
{
    Hwy_FX_SIZE() : field_1(0), field_2(0), updatetime(0), field_type(0), field_size(0){}

    Hwy_package_len     pack_len;
    char                        Fx_name[20];            //名称，例如USD.CHF
    unsigned long               updatetime;             //更新时间
    int                         field_type;             //用于区分field_size是买量还是卖量
    float                       field_size;             //变化尺寸
    float                       field_1;                //最后价尺寸                 
    float                       field_2;                //交易量                       
};


struct Hwy_FX_LIST
{
    Hwy_package_len     pack_len;
};

struct Hwy_Req_FX
{
    char fx_code[12];
    int  need;  //0表示取消订阅
};

#pragma pack()