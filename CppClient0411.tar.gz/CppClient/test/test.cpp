#include <iostream>
#include <memory>
#include <string>
#include "EWrapper.h"

using namespace std;

class EClient;
class HClientBase: public EWrapper
{
public:

protected:
    auto_ptr<EClient> h_pClient;
};

int main(void)
{
   cout << "helll world" << endl;
}
